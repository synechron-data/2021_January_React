import React, { Component } from 'react';
import { Link, Route } from 'react-router-dom';

import './ProductsComponent.css';

class ProductsComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            productsData: [
                {
                    id: 1,
                    name: "Item One",
                    description:
                        "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
                    status: "Available"
                },
                {
                    id: 2,
                    name: "Item Two",
                    description: "sunt aut facere ptio reprehenderit",
                    status: "Not Available"
                },
                {
                    id: 3,
                    name: "Item Three",
                    description: "provident occaecati excepturi optio reprehenderit",
                    status: "Available"
                },
                {
                    id: 4,
                    name: "Item Four",
                    description: "reprehenderit",
                    status: "Not Available"
                }
            ]
        }
    }

    render() {
        let pList = this.state.productsData.map(product =>
            <li key={product.id} className="list-group-item">
                <Link to={`${this.props.match.url}/${product.id}`}>{product.name}</Link>
            </li>
        );

        return (
            <div>
                <h1 className="text-info">Products Component</h1>
                <div>
                    <div className="graybox">
                        <ul className="list-group">
                            {pList}
                        </ul>
                    </div>
                </div>

                <Route exact path={this.props.match.url} render={
                    (props) => (
                        <ProductNotSelectedComponent />
                    )
                } />

                <Route exact path={`${this.props.match.url}/:productId`} render={
                    (props) => (
                        <ProductDetailsComponent data={this.state.productsData} {...props} />
                    )
                } />
            </div>
        );
    }
}

const ProductNotSelectedComponent = () => {
    return (
        <div className="outerdiv">
            <div className="innerdiv">
                <h2 className="text-warning">Please select a product.</h2>
            </div>
        </div>
    );
}

const ProductDetailsComponent = ({ data, match }) => {
    let product = data.find(p => p.id === parseInt(match.params.productId));

    let productView;

    if (product) {
        productView = (
            <div>
                <h3>{product.name}</h3>
                <p>{product.description}</p>
                <hr />
                <h4 className={product.status === 'Available' ? 'text-success' : 'text-danger'}>{product.status}</h4>
            </div>
        );
    } else {
        productView = (<h3 className="text-danger">Product not found.</h3>);
    }

    return (
        <div className="outerdiv">
            <div className="innerdiv">
                {productView}
            </div>
        </div>
    );
}

export default ProductsComponent;