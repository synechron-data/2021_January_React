import 'bootstrap/scss/bootstrap.scss';
import './index.css';

import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap';
import { BrowserRouter } from 'react-router-dom';

import RootComponent from './components/root/RootComponent';

ReactDOM.render(<React.StrictMode>
  <BrowserRouter>
    <RootComponent />
  </BrowserRouter>
</React.StrictMode>, document.getElementById('root'));

if (module.hot) {
  module.hot.accept() // already had this init code 

  module.hot.addStatusHandler(status => {
    if (status === 'prepare') console.clear()
  })
}