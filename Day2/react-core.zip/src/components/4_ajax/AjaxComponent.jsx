import React, { Component } from 'react';
import postApiClient from '../../services/post_api_client';
import DataTable from '../common/DataTable';
import LoaderAnimation from '../common/LoaderAnimation';

// const ListItem = ({ item }) => {
//     return (
//         <li className="list-group-item">
//             <h3>Id: {item.id}</h3>
//             <h4>{item.title}</h4>
//             <p>{item.body}</p>
//         </li>
//     );
// }

class AjaxComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { posts: [], message: "Loading Data, please wait....", flag: true };
    }

    render() {
        // var listItems = this.state.posts.map((item, index) => {
        //     return <ListItem key={index} item={item} />;
        // });

        return (
            <>
                <div className="row">
                    <h4 className="text-warning text-center text-uppercase font-weight-bold">{this.state.message}</h4>
                </div>

                {
                    this.state.flag ?
                        <div className="pt-5">
                            <LoaderAnimation />
                        </div> :
                        null
                }

                {/* <ul className="list-group">
                    {listItems}
                </ul> */}

                {/* Please display a table instead of ul and li */}
                <DataTable items={this.state.posts}>
                    <h4 className="text-primary text-uppercase font-weight-bold">Posts Table</h4>
                </DataTable>
            </>
        );
    }

    componentDidMount() {
        postApiClient.getAllPosts().then(data => {
            this.setState({ posts: [...data], message: "", flag: false });
        }).catch(eMsg => {
            this.setState({ posts: [], message: eMsg, flag: false });
        });
    }
}

export default AjaxComponent;