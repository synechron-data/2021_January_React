import React, { Component, useState } from 'react';

class UsingClass extends Component {
    constructor(props) {
        super(props);
        this.state = { count: 0 };
        this.inc = this.inc.bind(this);
        this.dec = this.dec.bind(this);
    }

    inc() {
        this.setState({ count: this.state.count + 1 });
    }

    dec() {
        this.setState({ count: this.state.count - 1 });
    }

    render() {
        return (
            <div>
                <h2 className="text-warning">Using Class Syntax</h2>
                <h2 className="text-info">Count: {this.state.count}</h2>
                <button className="btn btn-primary" onClick={this.inc}>+</button>
                <button className="btn btn-primary" onClick={this.dec}>-</button>
            </div>
        );
    }
}

const UsingFunction = () => {
    // const obj = useState(0);
    // console.log(obj);

    const [count, setCount] = useState(0);

    return (
        <div>
            <h2 className="text-warning">Using Function Syntax</h2>
            <h2 className="text-info">Count: {count}</h2>
            <button className="btn btn-primary" onClick={() => setCount(count + 1)}>+</button>
            <button className="btn btn-primary" onClick={() => setCount(count - 1)}>-</button>
        </div>
    );
};

class StateHookDemo extends Component {
    render() {
        return (
            <div>
                <UsingClass />
                <UsingFunction />
            </div>
        );
    }
}

export default StateHookDemo;