/* eslint-disable */
import React, { Component } from 'react';

import CalculatorAssignment from '../assignment/CalculatorAssignment';
import CounterAssignment from '../assignment/CounterAssignment';
import PropTypesDemo from '../1_prop-types/PropTypesDemo';
import ErrorHandler from '../common/ErrorHandler';
import ListRoot from '../2_list/ListComponent';
import ParentComponent from '../3-lifecycle-demo/DemoComponent';
import AjaxComponent from '../4_ajax/AjaxComponent';
import ContextAPIDemo from '../5_context-api/ContextAPIDemo';
import StateHookDemo from '../6_hooks/StateHookDemo';

class RootComponent extends Component {
    
    render() {
        return (
            <div className="container">
                <ErrorHandler>
                    {/* <CalculatorAssignment /> */}
                    {/* <CounterAssignment /> */}
                    {/* <PropTypesDemo /> */}
                    {/* <ListRoot /> */}
                    {/* <ParentComponent /> */}
                    {/* <AjaxComponent /> */}
                    {/* <ContextAPIDemo /> */}
                    <StateHookDemo />
                </ErrorHandler>
            </div>
        );
    }
}

export default RootComponent;