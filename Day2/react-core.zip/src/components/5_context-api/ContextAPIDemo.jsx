// ----------------------------------------------------------------------------------------- Context API

import React, { Component } from 'react';
import postApiClient from '../../services/post_api_client';
import DataTable from '../common/DataTable';
import LoaderAnimation from '../common/LoaderAnimation';

// const obj = React.createContext();
// console.log(obj);

const { Provider, Consumer } = React.createContext();

class ChildComponentOne extends Component {
    render() {
        return (
            <div>
                <h3 className="text-info">Child One</h3>
                <ChildComponentTwo />
            </div>
        );
    }
}

class ChildComponentTwo extends Component {
    render() {
        return (
            <div>
                <h3 className="text-info">Child Two</h3>
                <Consumer>
                    {
                        (data) => (
                            <DataTable items={data}>
                                <h4 className="text-primary text-uppercase font-weight-bold">Posts Table</h4>
                            </DataTable>
                        )
                    }
                </Consumer>
                <Consumer>
                    {
                        (data) => (
                            <DataTable items={data}>
                                <h4 className="text-primary text-uppercase font-weight-bold">Posts Table</h4>
                            </DataTable>
                        )
                    }
                </Consumer>
            </div>
        );
    }
}

class ContextAPIDemo extends Component {
    constructor(props) {
        super(props);
        this.state = { posts: [], message: "Loading Data, please wait....", flag: true };
    }

    render() {
        return (
            <>
                <div className="row">
                    <h3 className="text-info">Main Component</h3>
                </div>
                <div className="row">
                    <h4 className="text-warning text-center text-uppercase font-weight-bold">{this.state.message}</h4>
                </div>

                {
                    this.state.flag ?
                        <div className="pt-5">
                            <LoaderAnimation />
                        </div> :
                        null
                }

                <Provider value={this.state.posts}>
                    <ChildComponentOne />
                </Provider>
            </>
        );
    }

    componentDidMount() {
        postApiClient.getAllPosts().then(data => {
            this.setState({ posts: [...data], message: "", flag: false });
        }).catch(eMsg => {
            this.setState({ posts: [], message: eMsg, flag: false });
        });
    }
}

export default ContextAPIDemo;
// -----------------------------------------------------------------------------------------
// import React, { Component } from 'react';
// import postApiClient from '../../services/post_api_client';
// import DataTable from '../common/DataTable';
// import LoaderAnimation from '../common/LoaderAnimation';

// class ChildComponentOne extends Component {
//     render() {
//         return (
//             <div>
//                 <h3 className="text-info">Child One</h3>
//                 <ChildComponentTwo data={this.props.data} />
//             </div>
//         );
//     }
// }

// class ChildComponentTwo extends Component {
//     render() {
//         return (
//             <div>
//                 <h3 className="text-info">Child Two</h3>
//                 <DataTable items={this.props.data}>
//                     <h4 className="text-primary text-uppercase font-weight-bold">Posts Table</h4>
//                 </DataTable>
//             </div>
//         );
//     }
// }

// class ContextAPIDemo extends Component {
//     constructor(props) {
//         super(props);
//         this.state = { posts: [], message: "Loading Data, please wait....", flag: true };
//     }

//     render() {
//         return (
//             <>
//                 <div className="row">
//                     <h3 className="text-info">Main Component</h3>
//                 </div>
//                 <div className="row">
//                     <h4 className="text-warning text-center text-uppercase font-weight-bold">{this.state.message}</h4>
//                 </div>

//                 {
//                     this.state.flag ?
//                         <div className="pt-5">
//                             <LoaderAnimation />
//                         </div> :
//                         null
//                 }

//                 <ChildComponentOne data={this.state.posts} />
//             </>
//         );
//     }

//     componentDidMount() {
//         postApiClient.getAllPosts().then(data => {
//             this.setState({ posts: [...data], message: "", flag: false });
//         }).catch(eMsg => {
//             this.setState({ posts: [], message: eMsg, flag: false });
//         });
//     }
// }

// export default ContextAPIDemo;