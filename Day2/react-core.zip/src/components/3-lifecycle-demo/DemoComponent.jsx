import React, { Component } from 'react';

class ChildComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { childState: 1 };
        console.log("Child - Ctor");
    }

    // UNSAFE_componentWillMount() {
    //     console.log("Child - componentWillMount");
    // }

    static getDerivedStateFromProps(props, state) {
        console.log("Child - getDerivedStateFromProps");
        return null;
    }

    getSnapshotBeforeUpdate(prevProps, prevState) {
        console.log("Child - getSnapshotBeforeUpdate");
        return null;
    }

    componentDidMount() {
        console.log("Child - componentDidMount");
    }

    handleClick(e) {
        this.setState({ childState: this.state.childState + 1 });
    }

    handleUpdate(e) {
        console.log("Child - forceUpdate");
        this.forceUpdate();
    }

    render() {
        console.log("Child - Render");
        return (
            <div>
                <h2 className="text-success">Child Component</h2>
                <h3 className="text-success">Value: {this.props.value}</h3>
                <h3 className="text-success">Child Value: {this.state.childState}</h3>
                <button className="btn btn-success" onClick={this.handleClick.bind(this)}>Change State</button>
                <button className="btn btn-success" onClick={this.handleUpdate.bind(this)}>Force Update</button>
            </div>
        );
    }

    // UNSAFE_componentWillReceiveProps(newProps) {
    //     console.log("Child - componentWillReceiveProps");
    // }

    shouldComponentUpdate(newProps, newState) {
        console.log("Child - shouldComponentUpdate");
        // return true;
        return false;
    }

    // UNSAFE_componentWillUpdate() {
    //     console.log("Child - componentWillUpdate");
    // }

    componentDidUpdate() {
        console.log("Child - componentDidUpdate");
    }

    componentWillUnmount() {
        console.log("Child - componentWillUnmount");
    }
}


class ParentComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { data: 0, flag: true };
        console.log("Parent - Ctor");
    }

    handleChange(e) {
        this.setState({ data: this.state.data + 1 });
    }

    handleLoad(e) {
        this.setState({ flag: !this.state.flag });
    }

    render() {
        console.log("Parent - Render");

        var child = this.state.flag ? null : (
            <ChildComponent value={this.state.data} />
        );

        return (
            <div>
                <br />
                <h2 className="text-info">Parent Component</h2>
                <h3 className="text-info">State: {this.state.data}</h3>
                <button className="btn btn-info" onClick={this.handleChange.bind(this)}>Change</button>
                <button className="btn btn-info" onClick={this.handleLoad.bind(this)}>Load/Unload</button>
                <hr />
                {child}
            </div>
        );
    }
}

export default ParentComponent;