import 'bootstrap/scss/bootstrap.scss';
import './index.css';

import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap';

import RootComponent from './components/root/RootComponent';

ReactDOM.render(<React.StrictMode>
  <RootComponent />
</React.StrictMode>, document.getElementById('root'));

// ReactDOM.render(<RootComponent />, document.getElementById('root'));

if (module.hot) {
  module.hot.accept() // already had this init code 

  module.hot.addStatusHandler(status => {
      if (status === 'prepare') console.clear()
  })
}