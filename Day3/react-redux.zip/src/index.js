// import 'bootstrap/scss/bootstrap.scss';
// import './index.css';

// import React from 'react';
// import ReactDOM from 'react-dom';
// import 'bootstrap';
// import { BrowserRouter } from 'react-router-dom';
// import { Provider } from 'react-redux';

// import RootComponent from './components/root/RootComponent';
// import configureStore from './store/configureStore';

// // const ReactProvider = React.createContext().Provider;
// // console.log(Provider);
// // console.log(ReactProvider);

// const appStore = configureStore();
// // const appStore = configureStore({ counterReducer: 1000 });
// // console.log(appStore.getState());

// ReactDOM.render(<React.StrictMode>
//   <Provider store={appStore}>
//     <BrowserRouter>
//       <RootComponent />
//     </BrowserRouter>
//   </Provider>
// </React.StrictMode>, document.getElementById('root'));

// if (module.hot) {
//   module.hot.accept()

//   module.hot.addStatusHandler(status => {
//     if (status === 'prepare') console.clear()
//   })
// }

// ------------------------------------------------------------------- 

import 'bootstrap/scss/bootstrap.scss';
import './index.css';

import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap';
import { Router } from 'react-router-dom';
import { Provider } from 'react-redux';

import RootComponent from './components/root/RootComponent';
import configureStore from './store/configureStore';
import history from './history';

const appStore = configureStore();

ReactDOM.render(<React.StrictMode>
  <Provider store={appStore}>
    <Router history={history}>
      <RootComponent />
    </Router>
  </Provider>
</React.StrictMode>, document.getElementById('root'));

if (module.hot) {
  module.hot.accept()

  module.hot.addStatusHandler(status => {
    if (status === 'prepare') console.clear()
  })
}