import productsAPIClient from '../services/products_api_client';
import * as actionTypes from './actionTypes';
import history from '../history';

function loadProductsRequested(msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_REQUESTED,
        payload: { message: msg, flag: false }
    };
}

function loadProductsSuccess(products, msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_SUCCESS,
        payload: { data: products, message: msg, flag: true }
    };
}

function loadProductsFailed(msg) {
    return {
        type: actionTypes.LOAD_PRODUCTS_FAILED,
        payload: { message: msg, flag: true }
    };
}

// A thunk is a function that wraps an expression for delaying the evaluation of that expression.
export function loadProducts() {
    return function (dispatch) {
        dispatch(loadProductsRequested("Products Request Started..."));

        productsAPIClient.getAllProducts().then((products) => {
            setTimeout(() => {
                dispatch(loadProductsSuccess(products, "Products Request Completed Successfully..."));
            }, 5000);
        }).catch((eMsg) => {
            dispatch(loadProductsFailed(eMsg));
        });
    }
}

// --------------------------------------------------- Insert

function insertProductsSuccess(product, msg) {
    return {
        type: actionTypes.INSERT_PRODUCT_SUCCESS,
        payload: { data: product, message: msg, flag: true }
    };
}

export function insertProduct(product) {
    return function (dispatch) {
        productsAPIClient.insertProduct(product).then((insertedProduct) => {
            dispatch(insertProductsSuccess(insertedProduct, "Product Inserted Successfully..."));
            history.push("/products");
        }).catch((eMsg) => {
            console.log(eMsg);
        });
    }
}

// --------------------------------------------------- Update or Edit

function updateProductsSuccess(product, msg) {
    return {
        type: actionTypes.UPDATE_PRODUCT_SUCCESS,
        payload: { data: product, message: msg, flag: true }
    };
}

export function updateProduct(product) {
    return function (dispatch) {
        productsAPIClient.updateProduct(product).then((updatedProduct) => {
            dispatch(updateProductsSuccess(updatedProduct, "Product Updated Successfully..."));
            history.push("/products");
        }).catch((eMsg) => {
            console.log(eMsg);
        });
    }
}

// --------------------------------------------------- Delete

function deleteProductsSuccess(product, msg) {
    return {
        type: actionTypes.DELETE_PRODUCT_SUCCESS,
        payload: { data: product, message: msg, flag: true }
    };
}

export function deleteProduct(product) {
    return function (dispatch) {
        productsAPIClient.deleteProduct(product).then(() => {
            dispatch(deleteProductsSuccess(product, "Product Deleted Successfully..."));
        }).catch((eMsg) => {
            console.log(eMsg);
        });
    }
}