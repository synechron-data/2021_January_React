// A higher-order component is a function that takes a component and returns a new component.

// import React, { Component } from 'react';

// class HOCDemo extends Component {
//     render() {
//         return (
//             <div>
//                 <h1 className="text-info">Higher Order Component Demo</h1>
//                 <h2 className="text-success">Some Data, added by HOC: {this.props.data}</h2>
//             </div>
//         );
//     }
// }

import React from 'react';

const HOCDemo = (props) => {
    return (
        <div>
            <h1 className="text-info">Higher Order Component Demo</h1>
            <h2 className="text-success">Some Data, added by HOC: {props.data}</h2>
        </div>
    );
}

const componentEnhancer = InputComponent => class extends React.Component {
    componentDidMount() {
        this.setState({ data: "Hello from HOC using Arrow" });
    }

    render() {
        return <InputComponent {...this.state} {...this.props} />
    }
}

// const componentEnhancer = function (InputComponent) {
//     return class extends React.Component {
//         componentDidMount() {
//             this.setState({ data: "Hello from HOC" });
//         }

//         render() {
//             return <InputComponent {...this.state} {...this.props} />
//         }
//     }
// }

const enhancedHOCDemo = componentEnhancer(HOCDemo);
export default enhancedHOCDemo;