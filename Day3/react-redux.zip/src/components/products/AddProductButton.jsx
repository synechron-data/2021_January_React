// import React from 'react';

// const AddProductButton = (props) => {
//     console.log(props);
//     return (
//         <button className="btn btn-primary" onClick={(e) => {
//             props.history.push('/product');
//         }}>
//             Add Product
//         </button>
//     );
// };

// export default AddProductButton;

// ------------------------------------------------------------

// import React from 'react';

// const AddProductButton = ({ history }) => {
//     return (
//         <button className="btn btn-primary" onClick={(e) => {
//             history.push('/product');
//         }}>
//             Add Product
//         </button>
//     );
// };

// export default AddProductButton;

// ------------------------------------------------------------

// import React from 'react';
// import { withRouter } from 'react-router-dom';

// const AddProductButton = withRouter(({ history }) => {
//     return (
//         <button className="btn btn-primary" onClick={(e) => {
//             history.push('/product');
//         }}>
//             Add Product
//         </button>
//     );
// });

// export default AddProductButton;

// ------------------------------------------------------------

import React from 'react';
import { withRouter } from 'react-router-dom';

const AddProductButton = ({ history }) => (
    <button className="btn btn-primary" onClick={(e) => {
        history.push('/product');
    }}>
        Add Product
    </button>
);

export default withRouter(AddProductButton);