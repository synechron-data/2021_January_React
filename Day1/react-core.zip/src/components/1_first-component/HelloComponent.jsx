// import React from 'react';

// class HelloComponent extends React.Component {
//     render() {
//         // return "Hello";
//         // return 1000;
//         // return true;
//         // return Symbol("Hello");
//         // return undefined;    // Error Nothing was returned from render
//         // return null;
//         return { id: 1 };       // Error Objects are not valid as a React child
//     }
// }

// export default HelloComponent;

// ---------------------------------------------------------

// import React from 'react';

// class HelloComponent extends React.Component {
//     // Should return a JSX Element
//     render() {
//         return <h1 className="abc">Hello World!</h1>;
//     }
// }

// export default HelloComponent;

// ---------------------------------------------------------

// import React, { Component } from 'react';

// class HelloComponent extends Component {
//     // Should return a JSX Element
//     render() {
//         return <h1 className="abc">Hello World!</h1>;
//     }
// }

// export default HelloComponent;

// ---------------------------------------------------------

// import React, { Component } from 'react';

// class HelloComponent extends Component {
//     // Should return only one JSX Element
//     render() {
//         return (
//             <div>
//                 <h1 className="abc">Hello World!</h1>
//                 <h1 className="abc">Hello World Again!</h1>
//             </div>
//         );
//     }
// }

// export default HelloComponent;

// ---------------------------------------------------------  React Fragments

// import React, { Component } from 'react';

// class HelloComponent extends Component {
//     // Should return only one JSX Element
//     render() {
//         return (
//             // <React.Fragment>
//             //     <h1 className="abc">Hello World!</h1>
//             //     <h1 className="abc">Hello World Again!</h1>
//             // </React.Fragment>
//             <>
//                 <h1 className="abc">Hello World!</h1>
//                 <h1 className="abc">Hello World Again!</h1>
//             </>
//         );
//     }
// }

// export default HelloComponent;

// ---------------------------------------------------------  Function Syntax

// import React from 'react';

// function HelloComponent() {
//     return (
//         <>
//             <h1 className="abc">Hello World!</h1>
//             <h1 className="abc">Using Function Declaration Syntax</h1>
//         </>
//     );
// }

// const HelloComponent = function () {
//     return (
//         <>
//             <h1 className="abc">Hello World!</h1>
//             <h1 className="abc">Using Function Expression Syntax</h1>
//         </>
//     );
// }

// const HelloComponent = () => {
//     return (
//         <>
//             <h1 className="abc">Hello World!</h1>
//             <h1 className="abc">Using Arrow Function Syntax</h1>
//         </>
//     );
// }

// const HelloComponent = () => (
//     <>
//         <h1 className="text-info">Hello World!</h1>
//         <h1 className="text-success">Using Single line Arrow Function Syntax</h1>
//     </>
// );

const HelloComponent = () => (
    <div className="container">
        <h1 className="text-info">Hello World!</h1>
        <h1 className="text-success">Using Single line Arrow Function Syntax</h1>
    </div>
);

export default HelloComponent;

// Class Syntax - Stateful Component / Container Component
// Function Syntax - Stateless Component / Presentational Component
