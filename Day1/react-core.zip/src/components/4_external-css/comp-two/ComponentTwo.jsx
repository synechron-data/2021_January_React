import React, { Component } from 'react';

import './ComponentTwo.css'

class ComponentTwo extends Component {
    render() {
        return (
            <>
                <h2 className="text-success">Hello from Component Two</h2>
                <h2 className="card2">From Component Two</h2>
            </>
        );
    }
}

export default ComponentTwo;