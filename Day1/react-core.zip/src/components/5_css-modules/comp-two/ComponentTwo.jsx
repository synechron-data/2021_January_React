import React, { Component } from 'react';

// import * as styles from './ComponentTwo.module.css';
import styles from './ComponentTwo.module.css';

class ComponentTwo extends Component {
    render() {
        return (
            <>
                <h2 className="text-success">Hello from Component Two</h2>
                <h2 className={styles.card}>From Component Two</h2>
            </>
        );
    }
}

export default ComponentTwo;