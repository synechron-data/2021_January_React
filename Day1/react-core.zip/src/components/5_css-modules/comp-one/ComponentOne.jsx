import React, { Component } from 'react';

import { card } from './ComponentOne.module.css';

class ComponentOne extends Component {
    render() {
        return (
            <>
                <h2 className="text-info">Hello from Component One</h2>
                <h2 className={card}>From Component One</h2>
            </>
        );
    }
}

export default ComponentOne;