// import React from 'react';
// import ReactDOM from 'react-dom';
// import HelloComponent from './components/1_first-component/HelloComponent';
// import './index.css';

// ReactDOM.render(
//   <React.StrictMode>
//     <HelloComponent />
//   </React.StrictMode>,
//   document.getElementById('root')
// );

// ----------------------------------------------------------- Using Bootstrap4
// npm i -D typescript@3.5
// npm i -D node-sass@4    
// npm i bootstrap popper.js jquery

// import 'bootstrap/scss/bootstrap.scss';
// import './index.css';

// import React from 'react';
// import ReactDOM from 'react-dom';
// import 'bootstrap';

// import HelloComponent from './components/1_first-component/HelloComponent';

// ReactDOM.render(
//   <React.StrictMode>
//     <HelloComponent />
//   </React.StrictMode>,
//   document.getElementById('root')
// );

// // ----------------------------------------------------------- Multiple Components

// import 'bootstrap/scss/bootstrap.scss';
// import './index.css';

// import React from 'react';
// import ReactDOM from 'react-dom';
// import 'bootstrap';

// import ComponentOne from './components/2_multi-components/ComponentOne';
// import ComponentTwo from './components/2_multi-components/ComponentTwo';

// // ReactDOM.render(<ComponentOne />, document.getElementById('root1'));
// // ReactDOM.render(<ComponentTwo />, document.getElementById('root2'));

// // ReactDOM.render(<React.Fragment>
// //   <ComponentOne />
// //   <ComponentTwo />
// // </React.Fragment>, document.getElementById('root'));

// // ReactDOM.render([<ComponentOne />, <ComponentTwo />], document.getElementById('root'));

// ReactDOM.render(<React.StrictMode>
//   <ComponentOne />
//   <ComponentTwo />
// </React.StrictMode>, document.getElementById('root'));

// ----------------------------------------------------------- Using Root Component

import 'bootstrap/scss/bootstrap.scss';
import './index.css';

import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap';

import RootComponent from './components/root/RootComponent';

ReactDOM.render(<React.StrictMode>
  <RootComponent />
</React.StrictMode>, document.getElementById('root'));
